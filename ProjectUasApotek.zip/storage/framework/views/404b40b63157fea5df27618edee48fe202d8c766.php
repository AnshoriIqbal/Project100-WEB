<?php $__env->startSection('content'); ?>
<section class="content-header">
      <h1>
        Input Obat
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Examples</a></li>
        <li class="active">Blank page</li>
      </ol>
</section>
<div class="content">
    <div class="panel panel-flat border-top-lg border-top-primary">
    <form action="<?php echo e((isset($Obat))?route('obat.update',$Obat->id_obat):route('obat.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php if(isset($Obat)): ?>?<?php echo method_field('PUT'); ?><?php endif; ?>
        <div class="panel-body">
            <div class="form-group">
                <label class="control-label col-lg-2">Nama Obat</label>
                <div class="col-lg-10">
                    <input type="text" value="<?php echo e((isset($Obat))?$Obat->nama_obat:old('nama_obat')); ?>" name="nama_obat" class="form-control" placeholder="Nama Obat....">
                    <?php $__errorArgs = ['nama_obat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small style="color:red"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <br>
                <br>
                <br>
                <label class="control-label col-lg-2">Jenis Obat</label>
                <div class="col-lg-10">
                    <input type="text" value="<?php echo e((isset($Obat))?$Obat->jenis_obat:old('jenis_obat')); ?>" name="jenis_obat" class="form-control" placeholder="Jenis Obat....">
                    <?php $__errorArgs = ['jenis_obat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small style="color:red"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                
                <br>
                <br>
                <br>
                <label class="control-label col-lg-2">Stock</label>
                <div class="col-lg-10">
                    <input type="text" value="<?php echo e((isset($Obat))?$Obat->stock:old('stock')); ?>" name="stock" class="form-control" placeholder="Stock Obat....">
                    <?php $__errorArgs = ['stock'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small style="color:red"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <br>
                <br>
                <br>
            </div>
            
            
            <div class="form-group">
                <button type="submit">SIMPAN</button>
            </div>
        </div>

    </form>    
    </div>
</div>    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ProjectUasApotek\resources\views/admin/inputobat.blade.php ENDPATH**/ ?>