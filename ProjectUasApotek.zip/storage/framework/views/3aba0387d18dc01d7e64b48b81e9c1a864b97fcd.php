<?php $__env->startSection('content'); ?>
<section class="content-header">
      <h1>
        Data Detail Penjualan
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Examples</a></li>
        <li class="active">Blank page</li>
      </ol>
</section>
<div class="content">
    <div class="panel panel-flat border-top-lg border-top-primary">
        <div class="panel-body">
            
            <div class="col-lg-12">
            <a href="<?php echo e(route('detailpenjualan.create')); ?>">Tambah Data</a>
                <table class="table table-bordered">
                    <thead>
                        <tr><th>No</th><th>Nama Obat</th><th>Id Penjualan</th><th>Harga</th><th>Aksi</th></tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $DetailPenjualan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $in=>$val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr><td><?php echo e(($in+1)); ?></td><td><?php echo e($val->nama_obat); ?></td><td><?php echo e($val->id_penjualan); ?></td><td><?php echo e($val->total); ?></td>
                        <td>
                        <a href="<?php echo e(route('detailpenjualan.edit',$val->id_detailpenjualan)); ?>"><button type="submit"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></button></a>
                        <form action="<?php echo e(route('detailpenjualan.destroy', $val->id_detailpenjualan)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                        <button type="submit"><i class="fa fa-trash" aria-hidden="true"></i></button>
                        </form>
                        </td></tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
       
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\apoteklaksamana\resources\views/admin/detailpenjualan.blade.php ENDPATH**/ ?>