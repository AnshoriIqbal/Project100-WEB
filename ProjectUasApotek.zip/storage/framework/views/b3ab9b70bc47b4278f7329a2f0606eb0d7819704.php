<?php $__env->startSection('content'); ?>
<section class="content-header">
      <h1>
        Data Supply
        </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Examples</a></li>
        <li class="active">Blank page</li>
      </ol>
</section>
<div class="content">
    <div class="panel panel-flat border-top-lg border-top-primary">
        <div class="panel-body">
            
            <div class="col-lg-12">
            <a href="<?php echo e(route('supply.create')); ?>">Tambah Data</a>
                <table class="table table-bordered">
                    <thead>
                        <tr><th>No</th><th>ID Supplier</th><th>ID Obat</th><th>Jumlah Barang</th><th>Tanggal Order</th><th>Tanggal Penerimaan Barang</th><th>Tanggal Bayar</th><th>Harga Total</th><th>ID Karyawan</th><th>Aksi</th></tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $Supply; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $in=>$val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr><td><?php echo e(($in+1)); ?></td><td><?php echo e($val->id_supplier); ?></td><td><?php echo e($val->id_obat); ?></td><td><?php echo e($val->quantity); ?></td><td><?php echo e($val->tanggalOrder); ?></td><td><?php echo e($val->tanggalPenerimaan); ?></td><td><?php echo e($val->tanggalBayar); ?></td><td><?php echo e($val->hargatotal); ?></td><td><?php echo e($val->id_karyawan); ?></td>
                        <td>
                        <a href="<?php echo e(route('supply.edit',$val->id_supply)); ?>"><button type="submit"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></button></a>
                        <form action="<?php echo e(route('supply.destroy', $val->id_supply)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                        <button type="submit"><i class="fa fa-trash" aria-hidden="true"></i></button>
                        </form>
                        </td></tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <?php echo e($Supply->links()); ?>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\apoteklaksamana\resources\views/admin/supply.blade.php ENDPATH**/ ?>