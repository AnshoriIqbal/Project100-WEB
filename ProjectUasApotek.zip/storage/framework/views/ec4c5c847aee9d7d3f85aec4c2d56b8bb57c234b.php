<?php $__env->startSection('content'); ?>
<section class="content-header">
      <h1>
        Input Detail Penjualan
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Examples</a></li>
        <li class="active">Blank page</li>
      </ol>
</section>
<div class="content">
    <div class="panel panel-flat border-top-lg border-top-primary">
    <form action="<?php echo e((isset($DetailPenjualan))?route('detailpenjualan.update',$DetailPenjualan->id_detailpenjualan):route('detailpenjualan.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php if(isset($Penjualan)): ?>?<?php echo method_field('PUT'); ?><?php endif; ?>
        <div class="panel-body">

                <label class="control-label col-lg-2">Nama Obat</label>
                <div class="col-lg-10">
                    
                     <select class="form-control" name="id_obat">
                            <option value="" holder>Pilih Nama Obat</option>
                            <?php $__currentLoopData = $obat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($result->id_obat); ?>"><?php echo e($result->nama_obat); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                    <?php $__errorArgs = ['id_obat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small style="color:red"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
             
                </div>
            <br>
            <br>

                <label class="control-label col-lg-2">Nama Pelanggan</label>
                <div class="col-lg-10">
                    
                     <select class="form-control" name="id_penjualan">
                            <option value="" holder>Pilih Nama Pelanggan</option>
                            <?php $__currentLoopData = $penjualan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($result->id_penjualan); ?>"><?php echo e($result->namapelanggan); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                    <?php $__errorArgs = ['id_penjualan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small style="color:red"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
             
                </div>
            <br>
            <br>
             <label class="control-label col-lg-2">Jumlah</label>
                <div class="col-lg-10">
                    <input type="number" value="<?php echo e((isset($DetailPenjualan))?$DetailPenjualan->jumlah:old('jumlah')); ?>" name="jumlah" class="form-control">
                    <?php $__errorArgs = ['jumlah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small style="color:red"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            <br>
            <br>

            <label class="control-label col-lg-2">Harga</label>
                <div class="col-lg-10">
                    <input type="number" value="<?php echo e((isset($DetailPenjualan))?$DetailPenjualan->harga:old('harga')); ?>" name="harga" class="form-control">
                    <?php $__errorArgs = ['harga'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small style="color:red"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            <br>
            <br>

            <div class="form-group">
                <button type="submit">SIMPAN</button>
            </div>
        </div>

    </form>    
    </div>
</div>    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\apoteklaksamana\resources\views/admin/inputdetailpenjualan.blade.php ENDPATH**/ ?>