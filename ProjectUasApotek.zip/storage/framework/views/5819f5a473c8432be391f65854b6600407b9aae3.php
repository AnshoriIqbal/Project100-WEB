<?php $__env->startSection('content'); ?>
<section class="content-header">
      <h1>
        Input Pelangan
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Examples</a></li>
        <li class="active">Blank page</li>
      </ol>
</section>
<div class="content">
    <div class="panel panel-flat border-top-lg border-top-primary">
    <form action="<?php echo e((isset($Pelanggan))?route('pelanggan.update',$Pelanggan->id_pelanggan):route('pelanggan.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php if(isset($Pelanggan)): ?>?<?php echo method_field('PUT'); ?><?php endif; ?>
        <div class="panel-body">
            <div class="form-group">
                <label class="control-label col-lg-2">Nama Pelanggan</label>
                <div class="col-lg-10">
                    <input type="text" value="<?php echo e((isset($Pelanggan))?$Pelanggan->namapelanggan:old('namapelanggan')); ?>" name="namapelanggan" class="form-control">
                    <?php $__errorArgs = ['namapelanggan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small style="color:red"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <label class="control-label col-lg-2">Alamat</label>
                <div class="col-lg-10">
                    <input type="text" value="<?php echo e((isset($Pelanggan))?$Pelanggan->alamat:old('alamat')); ?>" name="alamat" class="form-control">
                    <?php $__errorArgs = ['alamat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small style="color:red"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <label class="control-label col-lg-2">Jenis Kelamin</label>
                <div class="col-lg-10">
                    <input type="text" value="<?php echo e((isset($Pelanggan))?$Pelanggan->jenisKelamin:old('jenisKelamin')); ?>" name="jenisKelamin" class="form-control">
                    <?php $__errorArgs = ['jenisKelamin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small style="color:red"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <label class="control-label col-lg-2">No Telepon</label>
                <div class="col-lg-10">
                    <input type="text" value="<?php echo e((isset($Pelanggan))?$Pelanggan->noTelp:old('noTelp')); ?>" name="noTelp" class="form-control">
                    <?php $__errorArgs = ['noTelp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small style="color:red"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
               
            </div>
            
            
            <div class="form-group">
                <button type="submit">SIMPAN</button>
            </div>
        </div>

    </form>    
    </div>
</div>    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\apoteklaksamana\resources\views/admin/inputpelanggan.blade.php ENDPATH**/ ?>