<?php $__env->startSection('content'); ?>
<section class="content-header">
      <h1>
        Input Penjualan
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Examples</a></li>
        <li class="active">Blank page</li>
      </ol>
</section>
<div class="content">
    <div class="panel panel-flat border-top-lg border-top-primary">
    <form action="<?php echo e((isset($Penjualan))?route('penjualan.update',$Penjualan->id_penjualan):route('penjualan.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php if(isset($Penjualan)): ?>?<?php echo method_field('PUT'); ?><?php endif; ?>
        <div class="panel-body">

             
            </div>
             <div class="form-group">
                <label class="control-label col-lg-2">Nama Karyawan</label>
                <div class="col-lg-10">
                     <select class="form-control" name="id_karyawan">
                            <option value="" holder>Pilih Nama Karyawan</option>
                            <?php $__currentLoopData = $Karyawan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($result->id_karyawan); ?>"><?php echo e($result->namaKaryawan); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                    <?php $__errorArgs = ['id_karyawan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small style="color:red"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <br>
                <br>
                <label class="control-label col-lg-2">Tanggal Penjualan</label>
                <div class="col-lg-10">
                    <input type="date" value="<?php echo e((isset($Penjualan))?$Penjualan->tanggalPenjualan:old('tanggalPenjualan')); ?>" name="tanggalPenjualan" class="form-control">
                    <?php $__errorArgs = ['tanggalPenjualan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small style="color:red"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <br>
                <br>
                <label class="control-label col-lg-2">Nama Pelanggan</label>
                <div class="col-lg-10">
                    
                     <select class="form-control" name="id_pelanggan">
                            <option value="" holder>Pilih Nama Pelanggan</option>
                            <?php $__currentLoopData = $Pelanggan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($result->id_pelanggan); ?>"><?php echo e($result->namapelanggan); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                    <?php $__errorArgs = ['id_Pelangan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small style="color:red"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
             
                </div>

                <input type="hidden" name="status" value="Belum Lunas">

            
            <br>
            <br>
            <div class="form-group">
                <button type="submit">SIMPAN</button>
            </div>
        </div>

    </form>    
    </div>
</div>    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\apoteklaksamana\resources\views/admin/inputpenjualan.blade.php ENDPATH**/ ?>