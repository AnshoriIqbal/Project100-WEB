<?php $__env->startSection('content'); ?>
<section class="content-header">
      <h1>
        Input Supply
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Examples</a></li>
        <li class="active">Blank page</li>
      </ol>
</section>
<div class="content">
    <div class="panel panel-flat border-top-lg border-top-primary">
    <form action="<?php echo e((isset($Supply))?route('supply.update',$Supply->id_supply):route('supply.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php if(isset($Supply)): ?>?<?php echo method_field('PUT'); ?><?php endif; ?>
        <div class="panel-body">
         
                <label class="control-label col-lg-2">ID Supplier</label>
                <div class="col-lg-10">
                <select class="form-control" name="id_supplier">
                            <option value="" holder>Pilih Nama Supplier</option>
                            <?php $__currentLoopData = $supplier; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($result->id_supplier); ?>"><?php echo e($result->namaSupplier); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                    <?php $__errorArgs = ['id_supplier'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small style="color:red"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <br>
                <br>
               
                <label class="control-label col-lg-2">ID Obat</label>
                <div class="col-lg-10">
                     <select class="form-control" name="id_obat">
                            <option value="" holder>Pilih Nama Obat</option>
                            <?php $__currentLoopData = $obat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($result->id_obat); ?>"><?php echo e($result->nama_obat); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                    <?php $__errorArgs = ['id_obat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small style="color:red"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                 <br>
                <br>
         
                <label class="control-label col-lg-2">Jumlah Barang</label>
                <div class="col-lg-10">
                    <input type="text" value="<?php echo e((isset($Supply))?$Supply->quantity:old('quantity')); ?>" name="quantity" class="form-control">
                    <?php $__errorArgs = ['quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small style="color:red"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                 <br>
                <br>
          
                <label class="control-label col-lg-2">Tanggal Order</label>
                <div class="col-lg-10">
                    <input type="date" value="<?php echo e((isset($Supply))?$Supply->tanggalOrder:old('tanggalOrder')); ?>" name="tanggalOrder" class="form-control">
                    <?php $__errorArgs = ['tanggalOrder'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small style="color:red"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                 <br>
                <br>
              
                <label class="control-label col-lg-2">Tanggal Penerimaan</label>
                <div class="col-lg-10">
                    <input type="date" value="<?php echo e((isset($Supply))?$Supply->tanggalPenerimaan:old('tanggalPenerimaan')); ?>" name="tanggalPenerimaan" class="form-control">
                    <?php $__errorArgs = ['tanggalPenerimaan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small style="color:red"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                 <br>
                <br>
               
                <label class="control-label col-lg-2">Tanggal Pembayaran</label>
                <div class="col-lg-10">
                    <input type="date" value="<?php echo e((isset($Supply))?$Supply->tanggalBayar:old('tanggalBayar')); ?>" name="tanggalBayar" class="form-control">
                    <?php $__errorArgs = ['tanggalBayar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small style="color:red"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                 <br>
                <br>
               
                <label class="control-label col-lg-2">Harga Total</label>
                <div class="col-lg-10">
                    <input type="text" value="<?php echo e((isset($Supply))?$Supply->hargatotal:old('hargatotal')); ?>" name="hargatotal" class="form-control">
                    <?php $__errorArgs = ['hargatotal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small style="color:red"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                 <br>
                <br>
                
                <label class="control-label col-lg-2">ID Karyawan</label>
                <div class="col-lg-10">
                     <select class="form-control" name="id_karyawan">
                            <option value="" holder>Pilih Nama Karyawan</option>
                            <?php $__currentLoopData = $karyawan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($result->id_karyawan); ?>"><?php echo e($result->namaKaryawan); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                    <?php $__errorArgs = ['id_karyawan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small style="color:red"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                 <br>
                <br>
           
                
            </div>
            
            
            <div class="form-group">
                <button type="submit">SIMPAN</button>
            </div>
        </div>

    </form>    
    </div>
</div>    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\apoteklaksamana\resources\views/admin/inputsupply.blade.php ENDPATH**/ ?>